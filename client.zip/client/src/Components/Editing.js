import React from 'react';
import './Editing.css';


function Edit () {
    
    return (
         <div>
            hello
        </div>
    )
}

export default Edit;